Acme Garden Supply: a deliberately imperfect 6-page practice site for the Toadstone classroom exercise.
Run:   python3 serve.py        (serves http://localhost:8099/ on your own machine only)
Keep it on port 8099 and the host name "localhost": the home page's canonical tag points there.
Files here are MIT licensed. Nothing leaves your machine.
