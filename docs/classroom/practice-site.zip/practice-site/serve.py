#!/usr/bin/env python3
"""Serve the Acme Garden practice site at http://localhost:8099/ (127.0.0.1 only).
Run from this folder:  python3 serve.py
/old-sale/ answers with a 301 redirect to /shop/ on purpose."""
import http.server, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
class H(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith('/old-sale'):
            self.send_response(301); self.send_header('Location', '/shop/'); self.end_headers(); return
        return super().do_GET()
    def log_message(self, *a): pass
print('Practice site on http://localhost:8099/  (Ctrl+C to stop)')
http.server.ThreadingHTTPServer(('127.0.0.1', 8099), H).serve_forever()
