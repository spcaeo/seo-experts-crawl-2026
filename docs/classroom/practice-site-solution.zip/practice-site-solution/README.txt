Acme Garden Supply: the SOLUTION version of the Toadstone classroom practice site (all fixes applied, including the stretch task).
Run:   python3 serve.py        (serves http://localhost:8099/ on your own machine only)
Keep it on port 8099 and the host name "localhost": the home page's canonical tag points there.
Files here are MIT licensed. Nothing leaves your machine.
